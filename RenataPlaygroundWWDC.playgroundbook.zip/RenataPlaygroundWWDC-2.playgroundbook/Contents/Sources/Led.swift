//
//  Led.swift
//  wwdcRenata
//
//  Created by IFCE on 16/03/17.
//  Copyright © 2017 IFCE. All rights reserved.
//

import UIKit

public class Led: NSObject {
    private var pos : Int?
    private var color : String?
    private var image : UIImage?
    private var state : String?
    
    public init(pos: Int, color: String){
        self.pos = pos
        self.color = color
        self.state = "LOW"
    }
    
    public func digitalWrite(state: String){
        self.state = state
    }
    
    public func getPos() -> Int{
        return self.pos!
    }
    public func getColor() -> String{
        return self.color!
    }
    
    public func setColor(_ color: String){
        self.color = self.checkColor()
    }
    
    public func setImage(){
        self.image = UIImage(named: self.checkColor())
    }
    
    public func getImage() -> UIImage{
        setImage()
        print("\(self.checkColor())")
        return self.image!
        
    }
    
    
    public func changeLedColor(){
        if self.color == "Red" {
            self.color = "Green"
        } else if self.color == "Green"{
            self.color = "Yellow"
        } else {
            self.color = "Red"
        }
    }
    
    
    var leds : [Led]?
    
    
    private func checkColor() -> String{
        if self.state == "HIGH" {
            if self.color == "Red" {
                return  "RedHIGH"
            } else if self.color == "Green" {
                return "GreenHIGH"
            } else if self.color == "Yellow" {
                return "YellowHIGH"
            }
        } else {
            if self.color == "Red" {
                return "RedLOW"
            } else if self.color == "Green" {
                return  "GreenLOW"
            } else if self.color == "Yellow" {
                return "YellowLOW"
            }
        }
        return  "RedLOW"
    }
    
    public func returnConstraintValue() -> CGFloat{
        switch self.pos! {
        case 0:
            return 202.0
        case 1 :
            return 185.0
        case 2 :
            return 168.0
        case 3 :
            return 151.0
        case 4 :
            return 134.0
        case 5 :
            return 117.0
        case 6 :
            return 100.0
        case 7 :
            return 83.0
        case 8 :
            return 53.0
        case 9 :
            return 36.0
        case 10 :
            return 19.0
        case 11 :
            return 2.0
        case 12 :
            return -15.0
        default:
            return -32.0
        }
    }
    
    
    
}
