//
//  ViewController.swift
//  wwdcRenata
//
//  Created by RenataFaria on 15/03/17.
//  Copyright © 2017 RenataFaria. All rights reserved.
//

import UIKit

@objc(ViewController)

public class ViewController: UIViewController {
   
    
    class UICustomGestureRecognizer : UITapGestureRecognizer {
        
        var thisLed : Led?
        // any more custom variables here
        
        init(target: AnyObject?, action: Selector, thisLed : Led) {
            super.init(target: target, action: action)
            
            self.thisLed = thisLed
        }
        
    }

    
    var leds : [Int : Led]? = [Int : Led]()
    var imgViewDictionary : [Int : Int]? = [Int : Int]()
    
    public func pinMode(ledpin: Int, state: String){
            let newLed = Led(pos: ledpin, color: "Red")
            leds?[ledpin] = newLed
            newLed.setImage()
            generateImageView(ledpin: ledpin, led: newLed, permitAddNew: true)
    }
    
    public func pinModeWithLed(_ led : Led, _ color: String){
        
        leds?[led.getPos()] = led
        led.setImage()
        generateImageView(ledpin: led.getPos(), led: led, permitAddNew: true)
    }
    
    public func deleteLed(_ ledPos: Int) {
        let x =  view.viewWithTag(ledPos)
        x?.removeFromSuperview()
        leds?.removeValue(forKey: ledPos)
    }
    
    func tapGestureReconize(_ sender: UICustomGestureRecognizer){
        if let myLed = sender.thisLed {
            myLed.changeLedColor()
            generateImageView(ledpin: myLed.getPos(), led: myLed, permitAddNew: false)
        }
    }

    
    func generateImageView(ledpin: Int, led: Led, permitAddNew: Bool) {
        var imageView : UIImageView
        let indexOfThisView = view.subviews.count - 1
        
        if let newImageView = imgViewDictionary?[ledpin] {
            let x =  view.viewWithTag(ledpin)
            x?.removeFromSuperview()
            
            imgViewDictionary?[ledpin]? = newImageView
            imageView = UIImageView(image: led.getImage())
            imageView.tag = ledpin
            view.addSubview(imageView)
            
            let heightConstraint =  NSLayoutConstraint(item: imageView, attribute:  .height, relatedBy: .equal, toItem: nil,attribute: NSLayoutAttribute.notAnAttribute, multiplier: 1.0, constant: 238)
            let widthConstraint =  NSLayoutConstraint(item: imageView, attribute:  .width, relatedBy: .equal, toItem: nil,attribute: NSLayoutAttribute.notAnAttribute, multiplier: 1.0, constant: 94)
            
            let AlignCenterX = NSLayoutConstraint(item: imageView, attribute:.centerX, relatedBy: .equal, toItem: arduinoImage, attribute: .centerX, multiplier: 1, constant: led.returnConstraintValue())
            let AlignCenterY = NSLayoutConstraint(item: imageView, attribute:.centerY, relatedBy: .equal, toItem: arduinoImage, attribute: .centerY, multiplier: 1, constant: -254.5)
            
            imageView.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([AlignCenterX,AlignCenterY, heightConstraint,widthConstraint])
            
            
            let tapGesture = UICustomGestureRecognizer(target: self, action: #selector(tapGestureReconize(_:)), thisLed: led)
            
            imageView.addGestureRecognizer(tapGesture)
            imageView.isUserInteractionEnabled = true

            
            
        } else if permitAddNew {
            let image = led.getImage()
            imageView = UIImageView(image: image)
            imageView.frame = CGRect(x: 0, y: 0, width: 94, height: 238)
            imgViewDictionary?[ledpin] = indexOfThisView
            leds?[ledpin] = led
            imageView.tag = ledpin
            view.addSubview(imageView)
            
            let heightConstraint =  NSLayoutConstraint(item: imageView, attribute:  .height, relatedBy: .equal, toItem: nil,attribute: NSLayoutAttribute.notAnAttribute, multiplier: 1.0, constant: 238)
            let widthConstraint =  NSLayoutConstraint(item: imageView, attribute:  .width, relatedBy: .equal, toItem: nil,attribute: NSLayoutAttribute.notAnAttribute, multiplier: 1.0, constant: 94)
            
            let AlignCenterX = NSLayoutConstraint(item: imageView, attribute:.centerX, relatedBy: .equal, toItem: arduinoImage, attribute: .centerX, multiplier: 1, constant: led.returnConstraintValue())
            let AlignCenterY = NSLayoutConstraint(item: imageView, attribute:.centerY, relatedBy: .equal, toItem: arduinoImage, attribute: .centerY, multiplier: 1, constant: -254.5)
            
            imageView.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([AlignCenterX,AlignCenterY, heightConstraint,widthConstraint])
            
            let tapGesture = UICustomGestureRecognizer(target: self, action: #selector(tapGestureReconize(_:)), thisLed: led)
            
            imageView.addGestureRecognizer(tapGesture)
            imageView.isUserInteractionEnabled = true

        }
    }
    
    @IBOutlet weak var arduinoImage: UIImageView!
    @IBOutlet weak var ledPin: UIImageView!
    @IBOutlet weak var contraint: NSLayoutConstraint!
    
    
    public func digitalWrite(ledPin: Int, state: String){
        if let modifiedLed = leds?[ledPin]{
            modifiedLed.digitalWrite(state: state)
            generateImageView(ledpin: ledPin , led: modifiedLed, permitAddNew: false)
        }
    }
    

    public override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    public override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

public extension ViewController {
    public class func instantiateFromStoryboard() -> ViewController {
        let storyBoard = UIStoryboard(name: "Main", bundle: Bundle.main)
        let viewController = storyBoard.instantiateInitialViewController() as!
        ViewController
        
        return viewController
    }
}

