//#-hidden-code
//  wwdcRenata
//
//  Created by RenataFaria on 20/03/17.
//  Copyright © 2017 RenataFaria. All rights reserved.
//
//#-end-hidden-code
/*:
 ## Learning how turn on and turn off a led
 Now you know how create a led but how can turn on or turn off it?
 
 To learn how to do this, It's important understandig what is a "digital pin".
 Arduino have two different type of pins: the digital and the analogic. You use those pins to control when will pass and not pass electricity. In analogic you need to pass a number that's control the intesity of the current and the digital you just use binary numbers to say when will pass and when will not pass.
 It's easier use digital than analogic to turn on/off leds and that's why the people used to put leds in digital.
 
 So, in arduino we use a function to write in the digital pin, indicating where your led is and write HIGH to pass current and LOW to not pass current.

 - Note:
 You just can write in a pin **after** configure this pin
 
 
 ````
 digitalWrite(whereIsYourLed, "STATE")
 ````
 
 >
 whereIsYourLed is a **int** \
 state is a **string**
 
 - Note:
 You'll need to write the state always with caps letters!
 
 ````
 digitalWrite(1, "HIGH")
 ````
 
 - important:
 HIGH - turn on \
LOW  - turn off
 
 
 ### Its time to test! Try turn on a led!
 ---
 */
//#-hidden-code
import PlaygroundSupport
import Foundation


var numberOfLeds : Int = 0

var myLedPositionArray : [PlaygroundValue] = [PlaygroundValue]()

func digitalWrite(_ led: Int, _ state: String){
    let page = PlaygroundPage.current
    if let proxy = page.liveView as?  PlaygroundRemoteLiveViewProxy {
        let ledPin: PlaygroundValue = .integer(led)
        let myDictionary = [state : ledPin]
        let thisLed: PlaygroundValue = .dictionary(myDictionary)
            proxy.send(thisLed)
    }
}

func pinMode(_ led: Int, _ state: String){
    let page = PlaygroundPage.current
    if let proxy = page.liveView as?  PlaygroundRemoteLiveViewProxy {
        
        //to send led
        let ledPin: PlaygroundValue = .integer(led)
        let myDictionary = [state : ledPin]
        let thisLed: PlaygroundValue = .dictionary(myDictionary)
        proxy.send(thisLed)
    }    
}

func delay(_ time : Int) {
    let ms = 1000
    let numberMs = time
    usleep(UInt32(numberMs * time))
}

func reloadLiveView(){
    let page = PlaygroundPage.current
    if let proxy = page.liveView as?  PlaygroundRemoteLiveViewProxy {
        //send my array
        let myLedArray = PlaygroundValue.array(myLedPositionArray)
        proxy.send(myLedArray)
    }
}

reloadLiveView()

//#-end-hidden-code
/*:
 void setup() {
 */
//#-editable-code
pinMode(1,"OUTPUT")
//#-end-editable-code

/*:
}
 
void loop(){
*/
//#-hidden-code
while true {
//#-end-hidden-code
//#-editable-code
//use digitalWrite here:
    
//#-end-editable-code
//#-hidden-code
delay(100)
}
//#-end-hidden-code


/*:
 }
 */
//:  [click here to go to next page](@next)


