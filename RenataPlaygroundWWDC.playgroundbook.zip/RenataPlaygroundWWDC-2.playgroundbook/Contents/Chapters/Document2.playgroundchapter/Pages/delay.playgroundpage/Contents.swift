//#-hidden-code
//  wwdcRenata
//
//  Created by RenataFaria on 20/03/17.
//  Copyright © 2017 RenataFaria. All rights reserved.
//
//#-end-hidden-code
/*:
 ## Learning what is a arduino delay
 
 Now you can create a led and you can turn on and turn off it! But maybe you realized something wrong...
 When you call the method to turn off a led right bellow a method to turn on a led you realize a big problem: It's really fast and you cannot see It working.
 So, because of this problem, arduino have a function named "delay" that waits some time and after continue reading your code. So, if you add a delay function between the turn on and off function you can see the leds turning on and off
 To write the delay funtion you have to:
 ````
 delay(time)
 ````
 - Important:
 This time is in **miliseconds** so if you want a 1 second delay you need to use 1000 instead 1
 
 ````
 delay(1000)
 ````
 
 ### Its time to test! Use delay to blink a led.
 ---
 void setup() {
 */

//#-hidden-code
import PlaygroundSupport
import Foundation


var numberOfLeds : Int = 0

var myLedPositionArray : [PlaygroundValue] = [PlaygroundValue]()

func digitalWrite(_ led: Int, _ state: String){
    let page = PlaygroundPage.current
    if let proxy = page.liveView as?  PlaygroundRemoteLiveViewProxy {
        let ledPin: PlaygroundValue = .integer(led)
        let myDictionary = [state : ledPin]
        let thisLed: PlaygroundValue = .dictionary(myDictionary)
            proxy.send(thisLed)
    }
}

func pinMode(_ led: Int, _ state: String){
    let page = PlaygroundPage.current
    if let proxy = page.liveView as?  PlaygroundRemoteLiveViewProxy {
        
        //to send led
        let ledPin: PlaygroundValue = .integer(led)
        let myDictionary = [state : ledPin]
        let thisLed: PlaygroundValue = .dictionary(myDictionary)
        proxy.send(thisLed)
    }    
}

func delay(_ time : Int) {
    let ms = 1000
    let numberMs = time
    usleep(UInt32(numberMs * time))
}

func reloadLiveView(){
    let page = PlaygroundPage.current
    if let proxy = page.liveView as?  PlaygroundRemoteLiveViewProxy {
        //send my array
        let myLedArray = PlaygroundValue.array(myLedPositionArray)
        proxy.send(myLedArray)
    }
}

reloadLiveView()

//#-end-hidden-code
//#-editable-code
pinMode(1,"OUTPUT")

//#-end-editable-code
/*:
}
 
void loop(){
*/
//#-hidden-code
while true {
//#-end-hidden-code
//#-editable-code
digitalWrite(1, "HIGH")
//delay:
    
//digitalWrite with LOW
    
//delay again:

//#-end-editable-code
//#-hidden-code
delay(100)
}
//#-end-hidden-code


/*:
 }
 */
//:  [click here to go to next topic](@next)



