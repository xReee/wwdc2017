import PlaygroundSupport


let viewController = ViewController.instantiateFromStoryboard()
let page = PlaygroundPage.current
PlaygroundPage.current.liveView = viewController

var contentsLeds : [PlaygroundValue] = [PlaygroundValue]()
var liveViewLeds : [PlaygroundValue] = [PlaygroundValue]()

var myDictionary : [Int : Led]? = [Int : Led]()

var contentsNumberOfLeds = 0

extension ViewController: PlaygroundLiveViewMessageHandler {
    
    public func receive(_ value: PlaygroundValue){
        //to execute my functions :]
        if case let.dictionary(dictionary) = value {
            //now I need to verify what I receive from my contents, if the key was OUTPUT I need to call my pinMode if is HIGH or LOW I need to use digitalWrite
            if let outputValue = dictionary["OUTPUT"], case let.integer(intValue) = outputValue {
                //ok, time to call my pinMode function, but before I need to verify if I added a led before this one, because my view not reloaded as my contents, so I need to verify if my contents' numbers of leds is equal to liveview's number of leds, if it's not I can add with no problems, but if it's true I need to delete this image view. So to get the position of the last led I need to put all led position and get this to delete
            
                    //continue normally
                if let thisLed = myDictionary?[intValue]  {
                            viewController.pinModeWithLed(thisLed, thisLed.getColor())
                            liveViewLeds.append(outputValue)

                    } else {
                        let newLed = Led(pos: intValue, color: "Red")
                        viewController.pinMode(ledpin: intValue, state: "OUTPUT")
                        myDictionary?[intValue] = newLed
                        liveViewLeds.append(outputValue)
                        }
                }
                else if let outputValue = dictionary["HIGH"], case let.integer(intValue) = outputValue {
                
                viewController.digitalWrite(ledPin: intValue, state: "HIGH")
            
            } else if let outputValue = dictionary["LOW"], case let.integer(intValue) = outputValue {
                
                viewController.digitalWrite(ledPin: intValue, state: "LOW")
            }
        } else if case let.array(array) = value {

            for led in liveViewLeds {
                if case let.integer(int) = led {
                    viewController.deleteLed(int)
                   // liveViewLeds.remove(at: int)
                }
            }
        }
    }
}



