//#-hidden-code
//  wwdcRenata
//
//  Created by RenataFaria on 20/03/17.
//  Copyright © 2017 RenataFaria. All rights reserved.
//
//#-end-hidden-code
/*:
 ## Understanding and configuring leds in arduino
 Let's start!
 First thing you need to know is how arduino works.
 
 If you look to this image on your right you will see the arduino board.
 This board can control things like leds and engines, but It's can receive also information from sensors, so you can create things using your creativity!
 
 So, we will start controlling a led, if you never saw one, that's how It's looks:
 
 ![This is a led](ledIcon.png)
 
 So, when you add a led in your arduino you need to warn him that you putted a thing that receive information and It's not one that send. For this you need to say where do you putted and the state is "OUTPUT". If was a sensor use "INPUT", in this tutorial we just work with leds.
 - Important:
    Normally we put leds in digital pins (located in the top of board)
 
 Furthermore, It's important know that Arduino have two big methods: setup and loop, the setup method you just run once, and after setup you will enter in a infinite loop (in method loop).
 
 So you need to warn arduino just once, and because of this, you just need to do it in the setup method, using:
 

    pinMode(whereIsYourLed, "state")
 

 >
whereIsYourLed is a **int** \
state is a **string**

 - Note:
 You'll need to write the state always with caps letters!
 
 ````
 pinMode(1, "OUTPUT")
 ````
 
 ### Its time to test! Try add a led in pin 4 using pinMode in  your setup method!
 ---

 void setup() {
 */

//#-hidden-code
import PlaygroundSupport
import Foundation


var numberOfLeds : Int = 0

var myLedPositionArray : [PlaygroundValue] = [PlaygroundValue]()

func digitalWrite(_ led: Int, _ state: String){
    let page = PlaygroundPage.current
    if let proxy = page.liveView as?  PlaygroundRemoteLiveViewProxy {
        let ledPin: PlaygroundValue = .integer(led)
        let myDictionary = [state : ledPin]
        let thisLed: PlaygroundValue = .dictionary(myDictionary)
            proxy.send(thisLed)
    }
}

func pinMode(_ led: Int, _ state: String){
    let page = PlaygroundPage.current
    if let proxy = page.liveView as?  PlaygroundRemoteLiveViewProxy {
        
        //to send led
        let ledPin: PlaygroundValue = .integer(led)
        let myDictionary = [state : ledPin]
        let thisLed: PlaygroundValue = .dictionary(myDictionary)
        proxy.send(thisLed)
    }    
}

func delay(_ time : Int) {
    let ms = 1000
    let numberMs = time
    usleep(UInt32(numberMs * time))
}

func reloadLiveView(){
    let page = PlaygroundPage.current
    if let proxy = page.liveView as?  PlaygroundRemoteLiveViewProxy {
        //send my array
        let myLedArray = PlaygroundValue.array(myLedPositionArray)
        proxy.send(myLedArray)
    }
}

reloadLiveView()

//#-end-hidden-code
//#-editable-code
//configure your led here:

//#-end-editable-code

//:}
//:
//:void loop(){

//#-hidden-code
while true {
//#-end-hidden-code
//#-editable-code
//#-end-editable-code
//#-hidden-code
delay(100)
}
//#-end-hidden-code


/*:
 }
 */

//:  [click here to go to next page](@next)

