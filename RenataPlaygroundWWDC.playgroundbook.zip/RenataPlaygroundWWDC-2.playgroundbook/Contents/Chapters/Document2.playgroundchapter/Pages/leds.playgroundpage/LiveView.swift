//#-hidden-code
//  wwdcRenata
//
//  Created by RenataFaria on 20/03/17.
//  Copyright © 2017 RenataFaria. All rights reserved.
//
//#-end-hidden-code
import PlaygroundSupport


let viewController = ViewController.instantiateFromStoryboard()
let page = PlaygroundPage.current
PlaygroundPage.current.liveView = viewController

var contentsLeds : [PlaygroundValue] = [PlaygroundValue]()
var liveViewLeds : [PlaygroundValue] = [PlaygroundValue]()

var myDictionary : [Int : Led]? = [Int : Led]()

var contentsNumberOfLeds = 0

extension ViewController: PlaygroundLiveViewMessageHandler {
    
    public func receive(_ value: PlaygroundValue){
        //to execute my functions :]
        if case let.dictionary(dictionary) = value {
            //now I need to verify what I receive from my contents, if the key was OUTPUT I need to call my pinMode if is HIGH or LOW I need to use digitalWrite
            if let outputValue = dictionary["OUTPUT"], case let.integer(intValue) = outputValue {
                if let thisLed = myDictionary?[intValue]  {
                            viewController.pinModeWithLed(thisLed, thisLed.getColor())
                            liveViewLeds.append(outputValue)

                    } else {
                        let newLed = Led(pos: intValue, color: "Red")
                        viewController.pinMode(ledpin: intValue, state: "OUTPUT")
                        myDictionary?[intValue] = newLed
                        liveViewLeds.append(outputValue)
                        }
                }
                else if let outputValue = dictionary["HIGH"], case let.integer(intValue) = outputValue {
                
                viewController.digitalWrite(ledPin: intValue, state: "HIGH")
            
            } else if let outputValue = dictionary["LOW"], case let.integer(intValue) = outputValue {
                
                viewController.digitalWrite(ledPin: intValue, state: "LOW")
            }
        } else if case let.array(array) = value {

            for led in liveViewLeds {
                if case let.integer(int) = led {
                    viewController.deleteLed(int)
                   // liveViewLeds.remove(at: int)
                }
            }
        }
    }
}



