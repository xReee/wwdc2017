//#-hidden-code
//  wwdcRenata
//
//  Created by RenataFaria on 15/03/17.
//  Copyright © 2017 RenataFaria. All rights reserved.
//
//#-end-hidden-code

//: ## Hello!
//: ### My name is **Renata** and I'm undergraduate student.
//: ### I like a lot of things, but two I really love: Swift and arduino.
//: ### Today, for my WWDC submition I will try to teach you one of my passion using the other. I hope you will pleased.
//: ### This is me:
//: ![This is me](Renata.jpg)
//: ## First of all: What is arduino?
//: Arduino is an open-source electronics platform based on easy-to-use hardware and software.
//: ## How works?
//: We have two things to learn: the electronic board and the code. Here we will improvise the board and learn just how the code works.
/*:
 >But, It's just an simple introduction, so if you want learn more, go to [Arduino Site]( https://www.arduino.cc ), buy the board and start to program this amazing thing!
 
 >A special thanks to Apple, Arduino and Fritzing that helps me to learn coding and be able to build this playground!\
 >[Arduino Site]( https://www.arduino.cc )\
 >[Fritzing site]( http://fritzing.org )
 
 ### So.. Let's start?
 [click here to go to next topic](@next)
 */

//#-end-hidden-code

//#-code-completion(everything, hide)


