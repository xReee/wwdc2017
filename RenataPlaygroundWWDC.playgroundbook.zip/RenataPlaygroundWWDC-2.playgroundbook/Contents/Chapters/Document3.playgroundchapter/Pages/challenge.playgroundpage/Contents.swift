//#-hidden-code
//  wwdcRenata
//
//  Created by RenataFaria on 20/03/17.
//  Copyright © 2017 RenataFaria. All rights reserved.
//
//#-end-hidden-code
/*:
 ## The traffic light challenge
 
 Ok you know all things that you need to create a cool traffic light! 
 
 But until now you just used red leds and the trafic lights have three different colors of leds. In real life arduino you'll need to pick 3 differents colors of leds, but in your playground you can change the color just tapping in the led **during** the loop method. 
 
 Ok, now that you know how change the colors it's time to practice!

 
 - Note:
 If you want, You can use these delay times in you traffic light:
    You can use as delay time:
    - 2 Seconds to green led
    - 1 Second to yellow led
    - 2 Seconds to red led
 
 - Important:
    You can add differents leds in your adruino just using a different pin number for each.\ **Always** remmember to configure your led pins with pinMode function **before** use others led's functions!
 
 ### Let's go! Do a traffic light!
 
 Remember the functions:
 * pinMode(1,"OUTPUT")
 * digitalWrite(1, "HIGH")
 * delay(1000)

 ---
 
 void setup() {
 
 */
//#-hidden-code
import PlaygroundSupport
import Foundation


var numberOfLeds : Int = 0

var myLedPositionArray : [PlaygroundValue] = [PlaygroundValue]()

func digitalWrite(_ led: Int, _ state: String){
    let page = PlaygroundPage.current
    if let proxy = page.liveView as?  PlaygroundRemoteLiveViewProxy {
        let ledPin: PlaygroundValue = .integer(led)
        let myDictionary = [state : ledPin]
        let thisLed: PlaygroundValue = .dictionary(myDictionary)
            proxy.send(thisLed)
    }
}

func pinMode(_ led: Int, _ state: String){
    let page = PlaygroundPage.current
    if let proxy = page.liveView as?  PlaygroundRemoteLiveViewProxy {
        
        //to send led
        let ledPin: PlaygroundValue = .integer(led)
        let myDictionary = [state : ledPin]
        let thisLed: PlaygroundValue = .dictionary(myDictionary)
        proxy.send(thisLed)
    }    
}

func delay(_ time : Int) {
    let ms = 1000
    let numberMs = time
    usleep(UInt32(numberMs * time))
}

func reloadLiveView(){
    let page = PlaygroundPage.current
    if let proxy = page.liveView as?  PlaygroundRemoteLiveViewProxy {
        //send my array
        let myLedArray = PlaygroundValue.array(myLedPositionArray)
        proxy.send(myLedArray)
    }
}

reloadLiveView()

//#-end-hidden-code
//#-editable-code
//configure your leds here:

//#-end-editable-code

//:}
//:
//:void loop(){

//#-hidden-code
while true {
//#-end-hidden-code
//#-editable-code
//Do your traffic light work:
//#-end-editable-code

//#-hidden-code
delay(100)
}
//#-end-hidden-code


/*:
 }
 */

//:  [click here to go to next page](@next)

